const $ = (id) => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
function show(el, text, good = true) {
  el.hidden = false; el.className = "result " + (good ? "good" : "bad"); el.textContent = text;
}
const statusNames = { received: "تم استلام الطلب", in_review: "قيد المتابعة", resolved: "تم تحديث الطلب إلى مكتمل", closed: "مغلق" };
$("requestForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = $("submitBtn"); btn.disabled = true; btn.textContent = "جاري الإرسال...";
  const result = $("result");
  try {
    const response = await fetch("/api/requests", {
      method: "POST", headers: {"content-type":"application/json"},
      body: JSON.stringify({
        username: $("username").value,
        contact: $("contact").value,
        details: $("details").value
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "تعذر إرسال الطلب.");
    show(result, `تم استلام طلبك بنجاح.\nرقم الطلب: ${data.id}\nاحتفظ بالرقم لمتابعة الحالة.\n${data.telegramSent ? "تم إرسال إشعار إلى فريق المتابعة." : "تم حفظ الطلب، لكن إشعار تليگرام غير مهيأ حالياً."}`);
    $("requestId").value = data.id;
    $("requestForm").reset();
  } catch (err) { show(result, err.message || "حدث خطأ، حاول مرة أخرى.", false); }
  finally { btn.disabled = false; btn.textContent = "إرسال الطلب"; }
});
$("lookupForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const out = $("lookupResult"); const id = $("requestId").value.trim().toUpperCase();
  try {
    const response = await fetch("/api/requests/" + encodeURIComponent(id));
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "تعذر العثور على الطلب.");
    show(out, `رقم الطلب: ${data.id}\nالحساب: @${data.username}\nالحالة: ${statusNames[data.status] || data.status}\nتاريخ التقديم: ${new Date(data.createdAt).toLocaleString("ar-IQ")}`);
  } catch (err) { show(out, err.message || "حدث خطأ.", false); }
});
