const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "requests.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]", "utf8");

function readRequests() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function saveRequests(rows) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(rows, null, 2), "utf8");
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
async function sendTelegram(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    console.warn("Telegram not configured: set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID.");
    return false;
  }
  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, disable_web_page_preview: true })
  });
  if (!response.ok) {
    const body = await response.text();
    console.error("Telegram API error:", response.status, body.slice(0, 300));
    return false;
  }
  return true;
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Bulldozer VIP" }));

app.post("/api/requests", async (req, res) => {
  const username = String(req.body?.username || "").trim().replace(/^@/, "");
  const contact = String(req.body?.contact || "").trim().slice(0, 120);
  const details = String(req.body?.details || "").trim().slice(0, 500);

  if (!/^[A-Za-z0-9._]{1,30}$/.test(username)) {
    return res.status(400).json({ error: "اكتب اسم مستخدم إنستغرام صحيح بدون رابط." });
  }

  const rows = readRequests();
  const id = crypto.randomBytes(4).toString("hex").toUpperCase();
  const item = {
    id, username, contact, details,
    status: "received",
    createdAt: new Date().toISOString()
  };
  rows.unshift(item);
  saveRequests(rows);

  const msg = [
    "📩 طلب جديد — Bulldozer VIP",
    `🆔 رقم الطلب: ${id}`,
    `📷 حساب إنستغرام: @${username}`,
    contact ? `☎️ وسيلة التواصل: ${contact}` : "",
    details ? `📝 التفاصيل: ${details}` : "",
    `🕒 الوقت: ${new Date(item.createdAt).toLocaleString("en-GB", { timeZone: "Asia/Baghdad" })}`,
    "",
    "ملاحظة: هذا إشعار باستلام الطلب فقط، وليس تأكيداً باسترجاع الحساب."
  ].filter(Boolean).join("\n");

  const telegramSent = await sendTelegram(msg);
  res.json({ ok: true, id, telegramSent });
});

app.get("/api/requests/:id", (req, res) => {
  const id = String(req.params.id || "").toUpperCase();
  const item = readRequests().find(x => x.id === id);
  if (!item) return res.status(404).json({ error: "ما لكينا طلب بهذا الرقم." });
  res.json({ id: item.id, username: item.username, status: item.status, createdAt: item.createdAt });
});

// Demo/admin status updates. Protect with ADMIN_KEY; never deploy with a blank key.
app.post("/api/admin/status/:id", async (req, res) => {
  const expected = process.env.ADMIN_KEY;
  const supplied = req.get("x-admin-key");
  if (!expected || expected.length < 16 || !safeEqual(supplied, expected)) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const allowed = ["received", "in_review", "resolved", "closed"];
  const status = String(req.body?.status || "");
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status" });
  const rows = readRequests();
  const item = rows.find(x => x.id === String(req.params.id).toUpperCase());
  if (!item) return res.status(404).json({ error: "Request not found" });
  item.status = status;
  item.updatedAt = new Date().toISOString();
  saveRequests(rows);
  await sendTelegram(`🔔 تحديث طلب Bulldozer VIP\n🆔 ${item.id}\n📷 @${item.username}\n📌 الحالة: ${status}`);
  res.json({ ok: true });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Bulldozer VIP listening on ${port}`));
